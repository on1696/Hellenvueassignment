const app = Vue.createApp({
    data() {
        return {
            title: 'VueBulb',
            image: './assets/images/lightOff.jpg',
            switchOn: false,
            states: [
              { id: 1, name:'On', color: 'yellow', image: './assets/images/lightOn.jpg' },
              { id: 2, name:'Off', color: 'black', image: './assets/images/lightOff.jpg' },
            ]
        }
    },
    methods: {
        updateImage(stateImage) {
            this.image = stateImage
        }
    }
})
